require("./index.js");

