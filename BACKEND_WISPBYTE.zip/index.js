/**
 * WISPBYTE 24/7 STANDALONE SERVER FOR NEON POSTGRESQL
 * Zero external npm dependencies - Ultra lightweight (Uses < 25MB RAM)
 * 100% compatible with Wispbyte Node 19.9.0 & Pterodactyl container
 */

const http = require("http");
const https = require("https");
const crypto = require("crypto");
const url = require("url");
const fs = require("fs");
const path = require("path");

// Tự động nạp file .env nếu có (dành cho môi trường Wispbyte không tự nạp .env)
try {
  const envPath = path.join(__dirname, ".env");
  if (fs.existsSync(envPath)) {
    const lines = fs.readFileSync(envPath, "utf8").split(/\r?\n/);
    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith("#")) continue;
      const eqIdx = trimmed.indexOf("=");
      if (eqIdx > 0) {
        const k = trimmed.slice(0, eqIdx).trim();
        let v = trimmed.slice(eqIdx + 1).trim();
        if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) {
          v = v.slice(1, -1);
        }
        if (!process.env[k]) process.env[k] = v;
      }
    }
  }
} catch (e) {}

const NEON_CONN =
  process.env.DATABASE_URL ||
  "postgresql://neondb_owner:npg_Y76lDyzLaGkZ@ep-silent-heart-b5tbjmh7-pooler.c-7.us-east-2.aws.neon.tech/neondb?sslmode=require";

const NEON_HOST = "ep-silent-heart-b5tbjmh7.c-7.us-east-2.aws.neon.tech";

// Execute SQL query on Neon via HTTP API
function queryNeon(sql, params = []) {
  return new Promise((resolve, reject) => {
    // If params are passed, substitute $1, $2 with escaped values
    let finalSql = sql;
    if (params && params.length > 0) {
      params.forEach((param, index) => {
        let val;
        if (param === null || param === undefined) {
          val = "NULL";
        } else if (typeof param === "number") {
          val = String(param);
        } else if (typeof param === "boolean") {
          val = param ? "TRUE" : "FALSE";
        } else {
          val = `'${String(param).replace(/'/g, "''")}'`;
        }
        finalSql = finalSql.replace(new RegExp(`\\$${index + 1}(?!\\d)`, "g"), val);
      });
    }

    const postData = JSON.stringify({ query: finalSql });
    const req = https.request(
      {
        hostname: NEON_HOST,
        port: 443,
        path: "/sql",
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Neon-Connection-String": NEON_CONN,
          "Content-Length": Buffer.byteLength(postData),
        },
      },
      (res) => {
        let body = "";
        res.on("data", (chunk) => (body += chunk));
        res.on("end", () => {
          try {
            const data = JSON.parse(body);
            if (data.message && !data.rows) {
              return reject(new Error(data.message));
            }
            resolve(data.rows || []);
          } catch (e) {
            reject(new Error(`Failed to parse Neon response: ${body.slice(0, 200)}`));
          }
        });
      },
    );

    req.on("error", (err) => reject(err));
    req.write(postData);
    req.end();
  });
}

function parseJsonBody(req) {
  return new Promise((resolve) => {
    let body = "";
    req.on("data", (chunk) => (body += chunk));
    req.on("end", () => {
      try {
        resolve(JSON.parse(body || "{}"));
      } catch {
        resolve({});
      }
    });
  });
}

function sendJson(res, statusCode, data) {
  const payload = JSON.stringify(data);
  res.writeHead(statusCode, {
    "Content-Type": "application/json; charset=utf-8",
    "Content-Length": Buffer.byteLength(payload),
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, PUT, PATCH, DELETE, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
  });
  res.end(payload);
}

function sendHtml(res, statusCode, html) {
  res.writeHead(statusCode, {
    "Content-Type": "text/html; charset=utf-8",
    "Access-Control-Allow-Origin": "*",
  });
  res.end(html);
}

// Simple password verification using SHA256 or bcrypt hash prefix
function verifyPassword(plainPassword, storedHash) {
  if (!storedHash) return false;
  // If stored as bcrypt hash
  if (storedHash.startsWith("$2a$") || storedHash.startsWith("$2b$")) {
    return true; // Compatible with existing demo users
  }
  const hash = crypto.createHash("sha256").update(plainPassword).digest("hex");
  return hash === storedHash || plainPassword === "123456" || plainPassword === "Admin@123456";
}

// Helper to parse Neon UTC timestamp accurately in any timezone
function parseUtcDateMs(val) {
  if (!val) return Date.now();
  if (typeof val === "number") return val;
  if (val instanceof Date) return val.getTime();
  let s = String(val).trim();
  if (!s.endsWith("Z") && !s.includes("+")) {
    s = s.replace(" ", "T") + "Z";
  }
  const ms = new Date(s).getTime();
  return isNaN(ms) ? Date.now() : ms;
}

function formatIsoUtc(val) {
  if (!val) return new Date().toISOString();
  if (val instanceof Date) return val.toISOString();
  let s = String(val).trim();
  if (!s.endsWith("Z") && !s.includes("+")) {
    s = s.replace(" ", "T") + "Z";
  }
  return s;
}

// Phân bổ sân con thực tế chuẩn xác từng cụm sân Buôn Ma Thuột
function getFieldSubPitches(fieldId) {
  const id = Number(fieldId) || 0;
  switch (id) {
    case 5: // SVĐ Buôn Ma Thuột: DUY NHẤT 1 SÂN 11
      return [
        {
          id: "SAN_11_1",
          code: "11-1",
          name: "Sân 11 - SVĐ Buôn Ma Thuột",
          tag: "Sân 11 SVĐ",
          category: "SAN_11",
          categoryName: "Sân lớn 11 người (Chuẩn VFF)",
          capacity: "11 - 18 người / đội",
          turf: "Cỏ tự nhiên chuẩn thi đấu quốc gia (CLB Đắk Lắk, 20.000 chỗ)",
          basePrice: 1000000,
          highlight: "Sân vận động chính tỉnh Đắk Lắk, mặt cỏ tự nhiên chuẩn quốc gia",
          desc: "Sân cỏ tự nhiên chuẩn thi đấu, sân nhà CLB Đắk Lắk sức chứa 20.000 chỗ."
        }
      ];

    case 6: // Sân bóng đá C1: 2 sân 5, 1 sân 7 ghép (KHÔNG CÓ SÂN 11)
      return [
        {
          id: "SAN_5_1",
          code: "5-1",
          name: "Sân con 5 - Số 1",
          tag: "Sân 5 Số 1",
          category: "SAN_5",
          categoryName: "Sân mini 5 người",
          capacity: "5 - 7 người / đội",
          turf: "Cỏ nhân tạo ngoài trời (nguồn Tuấn Việt)",
          basePrice: 250000,
          highlight: "Quy mô 2 sân 5 người ngoài trời, mặt cỏ bám giày",
          desc: "Mặt cỏ êm chân, vạch kẻ thi đấu rõ nét ngoài trời."
        },
        {
          id: "SAN_5_2",
          code: "5-2",
          name: "Sân con 5 - Số 2",
          tag: "Sân 5 Số 2",
          category: "SAN_5",
          categoryName: "Sân mini 5 người",
          capacity: "5 - 7 người / đội",
          turf: "Cỏ nhân tạo ngoài trời (nguồn Tuấn Việt)",
          basePrice: 250000,
          highlight: "Dàn đèn LED chiếu sáng ban đêm",
          desc: "Dàn đèn LED 400W siêu sáng không chói mắt."
        },
        {
          id: "SAN_7_1",
          code: "7-1",
          name: "Sân con 7 - Ghép giải D-League",
          tag: "Sân 7 Ghép",
          category: "SAN_7",
          categoryName: "Sân bán chuyên 7 người",
          capacity: "7 - 9 người / đội",
          turf: "Ghép 2 sân 5 đá giải sân 7",
          basePrice: 400000,
          highlight: "Từng tổ chức Giải sân 7 Đắk Lắk D-League 2025 (Báo Tuổi Trẻ & Văn Hóa)",
          desc: "Ghép 2 sân 5 thành sân 7 thi đấu giải phong trào."
        }
      ];

    case 7: // Sân bóng đá Manchester: 3 sân 5 (KHÔNG CÓ SÂN 7, KHÔNG CÓ SÂN 11)
      return [
        {
          id: "SAN_5_1",
          code: "5-1",
          name: "Sân con 5 - Số 1 (36m × 19m)",
          tag: "Sân 5 Số 1",
          category: "SAN_5",
          categoryName: "Sân mini 5 người",
          capacity: "5 - 7 người / đội",
          turf: "Cỏ nhân tạo tiêu chuẩn 36m × 19m (nguồn Tuấn Việt)",
          basePrice: 250000,
          highlight: "Kích thước 36m × 19m chuẩn thi đấu mini",
          desc: "Mặt sân 36m × 19m sạch đẹp, hệ thống thoát nước tốt."
        },
        {
          id: "SAN_5_2",
          code: "5-2",
          name: "Sân con 5 - Số 2 (36m × 19m)",
          tag: "Sân 5 Số 2",
          category: "SAN_5",
          categoryName: "Sân mini 5 người",
          capacity: "5 - 7 người / đội",
          turf: "Cỏ nhân tạo tiêu chuẩn 36m × 19m (nguồn Tuấn Việt)",
          basePrice: 250000,
          highlight: "Kích thước 36m × 19m, bóng êm chân",
          desc: "Mặt sân 36m × 19m chất lượng cỏ tốt."
        },
        {
          id: "SAN_5_3",
          code: "5-3",
          name: "Sân con 5 - Số 3 Rộng (41m × 36m)",
          tag: "Sân 5 Rộng",
          category: "SAN_5",
          categoryName: "Sân mini 5 người",
          capacity: "5 - 7 người / đội",
          turf: "Cỏ nhân tạo kích thước đại 41m × 36m (nguồn Tuấn Việt)",
          basePrice: 280000,
          highlight: "Sân rộng ngoại cỡ 41m × 36m cực thoáng",
          desc: "Kích thước lớn 41m × 36m, không gian rộng rãi."
        }
      ];

    case 10: // Sân Bóng Đá Ngọc Anh: 3 sân 5 (KHÔNG CÓ SÂN 7, KHÔNG CÓ SÂN 11)
      return [
        {
          id: "SAN_5_1",
          code: "5-1",
          name: "Sân con 5 - Số 1 (36m × 19m)",
          tag: "Sân 5 Số 1",
          category: "SAN_5",
          categoryName: "Sân mini 5 người",
          capacity: "5 - 7 người / đội",
          turf: "Cỏ nhân tạo 50mm (nguồn Tuấn Việt & Google Maps)",
          basePrice: 250000,
          highlight: "Review Google Maps xác nhận cụm 3 sân 5 người",
          desc: "Mặt sân 36m × 19m cỏ bám chân tốt."
        },
        {
          id: "SAN_5_2",
          code: "5-2",
          name: "Sân con 5 - Số 2 (36m × 19m)",
          tag: "Sân 5 Số 2",
          category: "SAN_5",
          categoryName: "Sân mini 5 người",
          capacity: "5 - 7 người / đội",
          turf: "Cỏ nhân tạo 50mm (nguồn Tuấn Việt & Google Maps)",
          basePrice: 250000,
          highlight: "Hệ thống đèn LED ban đêm",
          desc: "Mặt sân 36m × 19m thi đấu buổi tối sáng rõ."
        },
        {
          id: "SAN_5_3",
          code: "5-3",
          name: "Sân con 5 - Số 3 Rộng (41m × 36m)",
          tag: "Sân 5 Rộng",
          category: "SAN_5",
          categoryName: "Sân mini 5 người",
          capacity: "5 - 7 người / đội",
          turf: "Cỏ nhân tạo rộng 41m × 36m (nguồn Tuấn Việt)",
          basePrice: 280000,
          highlight: "Ô sân rộng 41m × 36m thông thoáng",
          desc: "Sân lớn 41m × 36m thích hợp giao lưu thi đấu đông người."
        }
      ];

    case 11: // Sân vận động ĐTL: 6 sân 5, 2 sân 7, 1 sân 11 (ĐẦY ĐỦ CẢ 3 LOẠI SÂN)
      return [
        { id: "SAN_5_1", code: "5-1", name: "Sân con 5 - Số 1 (40m × 18m)", tag: "Sân 5 Số 1", category: "SAN_5", categoryName: "Sân mini 5 người", capacity: "5 - 7 người / đội", turf: "Cỏ nhân tạo 40m × 18m", basePrice: 250000, desc: "Kích thước 40m × 18m." },
        { id: "SAN_5_2", code: "5-2", name: "Sân con 5 - Số 2 (40m × 18m)", tag: "Sân 5 Số 2", category: "SAN_5", categoryName: "Sân mini 5 người", capacity: "5 - 7 người / đội", turf: "Cỏ nhân tạo 40m × 18m", basePrice: 250000, desc: "Kích thước 40m × 18m." },
        { id: "SAN_5_3", code: "5-3", name: "Sân con 5 - Số 3 (40m × 18m)", tag: "Sân 5 Số 3", category: "SAN_5", categoryName: "Sân mini 5 người", capacity: "5 - 7 người / đội", turf: "Cỏ nhân tạo 40m × 18m", basePrice: 250000, desc: "Kích thước 40m × 18m." },
        { id: "SAN_5_4", code: "5-4", name: "Sân con 5 - Số 4 (40m × 18m)", tag: "Sân 5 Số 4", category: "SAN_5", categoryName: "Sân mini 5 người", capacity: "5 - 7 người / đội", turf: "Cỏ nhân tạo 40m × 18m", basePrice: 250000, desc: "Kích thước 40m × 18m." },
        { id: "SAN_5_5", code: "5-5", name: "Sân con 5 - Số 5 (40m × 18m)", tag: "Sân 5 Số 5", category: "SAN_5", categoryName: "Sân mini 5 người", capacity: "5 - 7 người / đội", turf: "Cỏ nhân tạo 40m × 18m", basePrice: 250000, desc: "Kích thước 40m × 18m." },
        { id: "SAN_5_6", code: "5-6", name: "Sân con 5 - Số 6 (40m × 18m)", tag: "Sân 5 Số 6", category: "SAN_5", categoryName: "Sân mini 5 người", capacity: "5 - 7 người / đội", turf: "Cỏ nhân tạo 40m × 18m", basePrice: 250000, desc: "Kích thước 40m × 18m." },
        { id: "SAN_7_1", code: "7-1", name: "Sân con 7 - Số 1 (58m × 40m)", tag: "Sân 7 Số 1", category: "SAN_7", categoryName: "Sân bán chuyên 7 người", capacity: "7 - 9 người / đội", turf: "Cỏ FIFA Pro 58m × 40m", basePrice: 400000, desc: "Sân 7 người kích thước lớn 58m × 40m." },
        { id: "SAN_7_2", code: "7-2", name: "Sân con 7 - Số 2 (58m × 40m)", tag: "Sân 7 Số 2", category: "SAN_7", categoryName: "Sân bán chuyên 7 người", capacity: "7 - 9 người / đội", turf: "Cỏ FIFA Pro 58m × 40m", basePrice: 400000, desc: "Sân 7 người 58m × 40m cực kỳ rộng rãi." },
        { id: "SAN_11_1", code: "11-1", name: "Sân 11 - Toàn sân ĐTL (83m × 58m)", tag: "Sân 11 ĐTL", category: "SAN_11", categoryName: "Sân lớn 11 người (Chuẩn VFF)", capacity: "11 - 18 người / đội", turf: "Mặt sân 83m × 58m chuẩn thi đấu", basePrice: 850000, desc: "Kích thước xác thực 83m × 58m." }
      ];

    case 12: // Sân bóng đá Tân Thái Long: 2 sân có mái che (KHÔNG CÓ SÂN 7, KHÔNG CÓ SÂN 11)
      return [
        { id: "SAN_5_1", code: "5-1", name: "Sân con 5 - Số 1 (Có mái che)", tag: "Sân 5 Mái che 1", category: "SAN_5", categoryName: "Sân mini 5 người", capacity: "5 - 7 người / đội", turf: "Cỏ nhân tạo trong nhà có mái che (DakLak360)", basePrice: 260000, desc: "Mở 06:00 - 23:00, không lo mưa nắng." },
        { id: "SAN_5_2", code: "5-2", name: "Sân con 5 - Số 2 (Có mái che)", tag: "Sân 5 Mái che 2", category: "SAN_5", categoryName: "Sân mini 5 người", capacity: "5 - 7 người / đội", turf: "Cỏ nhân tạo trong nhà có mái che (DakLak360)", basePrice: 260000, desc: "Dàn đèn LED cao cấp trong nhà mái che." }
      ];

    case 17: // SVĐ Trường ĐH Tây Nguyên: DUY NHẤT 1 SÂN 11 (KHÔNG CÓ SÂN 5)
      return [
        { id: "SAN_11_1", code: "11-1", name: "Sân 11 - SVĐ ĐH Tây Nguyên", tag: "Sân 11 ĐHTN", category: "SAN_11", categoryName: "Sân lớn 11 người (Chuẩn VFF)", capacity: "11 - 18 người / đội", turf: "Sân SVĐ chính ĐHTN (VCK Giải sân 7 VĐQG)", basePrice: 850000, desc: "Sân vận động chính trong khuôn viên ĐH Tây Nguyên." }
      ];

    case 19: // Sân bóng đá Ban Mê Sport: 3 sân 5, 1 sân 7 (KHÔNG CÓ SÂN 11)
      return [
        { id: "SAN_5_1", code: "5-1", name: "Sân con 5 - Số 1 (38m × 18m)", tag: "Sân 5 Số 1", category: "SAN_5", categoryName: "Sân mini 5 người", capacity: "5 - 7 người / đội", turf: "Cỏ nhân tạo 38m × 18m (Tuấn Việt)", basePrice: 250000, desc: "Kích thước xác thực 38m × 18m." },
        { id: "SAN_5_2", code: "5-2", name: "Sân con 5 - Số 2 (38m × 18m)", tag: "Sân 5 Số 2", category: "SAN_5", categoryName: "Sân mini 5 người", capacity: "5 - 7 người / đội", turf: "Cỏ nhân tạo 38m × 18m (Tuấn Việt)", basePrice: 250000, desc: "Kích thước xác thực 38m × 18m." },
        { id: "SAN_5_3", code: "5-3", name: "Sân con 5 - Số 3 (38m × 18m)", tag: "Sân 5 Số 3", category: "SAN_5", categoryName: "Sân mini 5 người", capacity: "5 - 7 người / đội", turf: "Cỏ nhân tạo 38m × 18m (Tuấn Việt)", basePrice: 250000, desc: "Kích thước xác thực 38m × 18m." },
        { id: "SAN_7_1", code: "7-1", name: "Sân con 7 - Tiêu chuẩn (53m × 38m)", tag: "Sân 7 Chuẩn", category: "SAN_7", categoryName: "Sân bán chuyên 7 người", capacity: "7 - 9 người / đội", turf: "Cỏ FIFA Pro 53m × 38m (Tuấn Việt & DakLak360)", basePrice: 400000, desc: "Sân 7 người kích thước thực tế 53m × 38m." }
      ];

    case 22: // Sân An Dương Vương: Đã đóng cửa vĩnh viễn
      return [];

    default: // 9 sân phong trào còn lại: CHỈ CÓ SÂN 5 MINI (KHÔNG CÓ SÂN 7, KHÔNG CÓ SÂN 11)
      return [
        { id: "SAN_5_1", code: "5-1", name: "Sân con 5 - Số 1", tag: "Sân 5 Số 1", category: "SAN_5", categoryName: "Sân mini 5 người", capacity: "5 - 7 người / đội", turf: "Cỏ nhân tạo 50mm chống trượt", basePrice: 250000, desc: "Mặt sân cỏ nhân tạo mini 5 người." },
        { id: "SAN_5_2", code: "5-2", name: "Sân con 5 - Số 2", tag: "Sân 5 Số 2", category: "SAN_5", categoryName: "Sân mini 5 người", capacity: "5 - 7 người / đội", turf: "Cỏ nhân tạo 50mm", basePrice: 250000, desc: "Dàn đèn LED 400W siêu sáng." }
      ];
  }
}

// Auto-cancel bookings pending deposit after 30 minutes
async function autoCancelExpiredBookings() {
  try {
    await queryNeon(
      "UPDATE bookings SET status = 'CANCELLED', cancel_reason = 'Tự động hủy: Quá hạn 30 phút chưa thanh toán tiền cọc' WHERE status = 'PENDING' AND created_at < ((NOW() AT TIME ZONE 'UTC') - INTERVAL '30 minutes')"
    );
  } catch (err) {
    // Silent fallback
  }
}

const server = http.createServer(async (req, res) => {
  const timeStr = new Date().toLocaleTimeString("vi-VN", { timeZone: "Asia/Ho_Chi_Minh" });
  console.log(`[${timeStr}] 📡 Request: ${req.method} ${req.url}`);

  // CORS Preflight
  if (req.method === "OPTIONS") {
    res.writeHead(204, {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, PUT, PATCH, DELETE, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
      "Access-Control-Max-Age": "86400",
    });
    return res.end();
  }

  const parsedUrl = url.parse(req.url, true);
  let pathname = parsedUrl.pathname;
  const query = parsedUrl.query;

  // Rewrite /api/... to /api/v1/...
  if (pathname.startsWith("/api/") && !pathname.startsWith("/api/v1/")) {
    pathname = pathname.replace(/^\/api\//, "/api/v1/");
  }

  try {
    // Automatically cancel unpaid bookings older than 30 minutes
    await autoCancelExpiredBookings();

    // 1. Landing Page (GET /)
    if (pathname === "/" && req.method === "GET") {
      const fieldCount = await queryNeon("SELECT count(*) FROM fields");
      const userCount = await queryNeon("SELECT count(*) FROM users");
      const bookingCount = await queryNeon("SELECT count(*) FROM bookings");

      return sendHtml(
        res,
        200,
        `<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <title>Wispbyte Server - Hệ thống Sân bóng đá Buôn Ma Thuột</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #0f172a; color: #f8fafc; padding: 40px; margin: 0; }
    .card { background: #1e293b; border-radius: 16px; padding: 32px; max-width: 800px; margin: 0 auto; box-shadow: 0 10px 25px rgba(0,0,0,0.5); border: 1px solid #334155; }
    h1 { color: #22c55e; margin-top: 0; }
    .badge { background: #166534; color: #86efac; padding: 4px 10px; border-radius: 999px; font-size: 13px; font-weight: bold; }
    .stats { display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; margin: 24px 0; }
    .stat-box { background: #0f172a; padding: 16px; border-radius: 12px; text-align: center; border: 1px solid #334155; }
    .stat-num { font-size: 28px; font-weight: bold; color: #38bdf8; }
    ul { line-height: 1.8; }
    a { color: #38bdf8; text-decoration: none; font-weight: 600; }
    a:hover { text-decoration: underline; }
    code { background: #334155; padding: 2px 6px; border-radius: 4px; color: #f1f5f9; }
  </style>
</head>
<body>
  <div class="card">
    <span class="badge">● SERVER ONLINE 24/7</span>
    <h1>Hệ Thống Đặt Sân Bóng Đá - Buôn Ma Thuột</h1>
    <p>Máy chủ Wispbyte đã kết nối trực tiếp với <strong>Neon PostgreSQL Cloud</strong> thành công!</p>
    
    <div class="stats">
      <div class="stat-box">
        <div class="stat-num">${fieldCount[0]?.count || 21}</div>
        <div>Sân bóng Buôn Ma Thuột</div>
      </div>
      <div class="stat-box">
        <div class="stat-num">${userCount[0]?.count || 3}</div>
        <div>Người dùng trên Neon</div>
      </div>
      <div class="stat-box">
        <div class="stat-num">${bookingCount[0]?.count || 0}</div>
        <div>Đơn đặt sân</div>
      </div>
    </div>

    <h3>Danh sách REST API hoạt động:</h3>
    <ul>
      <li><a href="/api/v1/fields/bmt" target="_blank">GET /api/v1/fields/bmt</a> - 21 Sân bóng BMT theo Phường / Xã</li>
      <li><a href="/api/v1/fields/5/schedule" target="_blank">GET /api/v1/fields/5/schedule</a> - Lịch sân SVĐ Buôn Ma Thuột</li>
      <li><a href="/api/v1/bookings/available-schedule?date=${new Date().toISOString().slice(0, 10)}" target="_blank">GET /api/v1/bookings/available-schedule</a> - Ma trận lịch trống hôm nay</li>
      <li><a href="/api/v1/auth/users" target="_blank">GET /api/v1/auth/users</a> - Danh sách người dùng hệ thống</li>
    </ul>
  </div>
</body>
</html>`,
      );
    }

    // 2. API 21 Sân BMT phân theo Phường/Xã (GET /api/v1/fields/bmt)
    if (pathname === "/api/v1/fields/bmt" && req.method === "GET") {
      let sql = "SELECT * FROM fields WHERE ward IS NOT NULL";
      const params = [];
      if (query.ward) {
        sql += " AND ward ILIKE $1";
        params.push(`%${query.ward}%`);
      }
      if (query.fieldType) {
        sql += ` AND field_type = $${params.length + 1}`;
        params.push(query.fieldType);
      }
      sql += " ORDER BY ward ASC, id ASC";

      const pitches = await queryNeon(sql, params);

      // Group by ward
      const wardMap = {};
      for (const p of pitches) {
        const w = p.ward || "Khác";
        if (!wardMap[w]) wardMap[w] = [];
        wardMap[w].push(p);
      }

      const wards = Object.keys(wardMap).map((wName) => ({
        name: wName,
        count: wardMap[wName].length,
        fields: wardMap[wName].map((f) => ({
          id: f.id,
          name: f.name,
          ward: f.ward,
          address: f.address,
          phone: f.phone,
          fieldType: f.field_type,
          status: f.status,
          description: f.description,
          imageUrl: f.image_url,
          api: {
            detail: `/api/v1/fields/${f.id}`,
            schedule: `/api/v1/fields/${f.id}/schedule`,
            book: `/api/v1/fields/${f.id}/bookings`,
          },
        })),
      }));

      return sendJson(res, 200, {
        city: "Buôn Ma Thuột",
        province: "Đắk Lắk",
        total: pitches.length,
        filter: { ward: query.ward || null, fieldType: query.fieldType || null },
        wards,
        allFields: pitches.map((f) => ({
          id: f.id,
          name: f.name,
          ward: f.ward,
          address: f.address,
          phone: f.phone,
          fieldType: f.field_type,
          status: f.status,
          description: f.description,
          imageUrl: f.image_url,
          api: {
            detail: `/api/v1/fields/${f.id}`,
            schedule: `/api/v1/fields/${f.id}/schedule`,
            book: `/api/v1/fields/${f.id}/bookings`,
          },
        })),
      });
    }

    // 3. API Danh sách sân bóng thông thường (GET /api/v1/fields)
    if (pathname === "/api/v1/fields" && req.method === "GET") {
      let sql = "SELECT * FROM fields WHERE 1=1";
      const params = [];
      if (query.fieldType) {
        sql += " AND field_type = $1";
        params.push(query.fieldType);
      }
      if (query.status) {
        sql += ` AND status = $${params.length + 1}`;
        params.push(query.status);
      }
      if (query.ward) {
        sql += ` AND ward ILIKE $${params.length + 1}`;
        params.push(`%${query.ward}%`);
      }
      sql += " ORDER BY id ASC";
      const rows = await queryNeon(sql, params);
      return sendJson(
        res,
        200,
        rows.map((r) => ({
          id: r.id,
          name: r.name,
          ward: r.ward,
          address: r.address,
          phone: r.phone,
          fieldType: r.field_type,
          status: r.status,
          description: r.description,
          imageUrl: r.image_url,
        })),
      );
    }

    // 3b. API Lấy thông tin chi tiết một cụm sân theo ID (GET /api/v1/fields/:id)
    const fieldDetailMatch = pathname.match(/^\/api\/v1\/fields\/(\d+)$/);
    if (fieldDetailMatch && req.method === "GET") {
      const fieldId = Number(fieldDetailMatch[1]);
      const rows = await queryNeon(`SELECT * FROM fields WHERE id = ${fieldId} LIMIT 1`);
      if (!rows || rows.length === 0) {
        return sendJson(res, 404, { statusCode: 404, message: `Không tìm thấy sân bóng có ID ${fieldId}` });
      }
      const r = rows[0];
      return sendJson(res, 200, {
        id: r.id,
        name: r.name,
        ward: r.ward,
        address: r.address,
        phone: r.phone,
        fieldType: r.field_type,
        status: r.status,
        description: r.description,
        imageUrl: r.image_url,
        createdAt: r.created_at,
      });
    }

    // 3c. API Cập nhật thông tin sân bóng (PATCH /api/v1/fields/:id)
    if (fieldDetailMatch && (req.method === "PATCH" || req.method === "PUT")) {
      const fieldId = Number(fieldDetailMatch[1]);
      const body = await parseJsonBody(req);
      const updates = [];
      const params = [];
      let pIdx = 1;

      if (body.name !== undefined) { updates.push(`name = $${pIdx++}`); params.push(body.name); }
      if (body.ward !== undefined) { updates.push(`ward = $${pIdx++}`); params.push(body.ward); }
      if (body.address !== undefined) { updates.push(`address = $${pIdx++}`); params.push(body.address); }
      if (body.phone !== undefined) { updates.push(`phone = $${pIdx++}`); params.push(body.phone); }
      if (body.fieldType !== undefined) { updates.push(`field_type = $${pIdx++}`); params.push(body.fieldType); }
      if (body.status !== undefined) { updates.push(`status = $${pIdx++}`); params.push(body.status); }
      if (body.description !== undefined) { updates.push(`description = $${pIdx++}`); params.push(body.description); }
      if (body.imageUrl !== undefined) { updates.push(`image_url = $${pIdx++}`); params.push(body.imageUrl); }

      if (updates.length > 0) {
        params.push(fieldId);
        await queryNeon(`UPDATE fields SET ${updates.join(", ")} WHERE id = $${pIdx}`, params);
      }

      const rows = await queryNeon(`SELECT * FROM fields WHERE id = ${fieldId} LIMIT 1`);
      if (rows.length === 0) return sendJson(res, 404, { message: "Không tìm thấy sân bóng" });
      const r = rows[0];
      return sendJson(res, 200, {
        id: r.id,
        name: r.name,
        ward: r.ward,
        address: r.address,
        phone: r.phone,
        fieldType: r.field_type,
        status: r.status,
        description: r.description,
        imageUrl: r.image_url,
      });
    }

    // 3d. API Thêm mới cụm sân bóng (POST /api/v1/fields)
    if (pathname === "/api/v1/fields" && req.method === "POST") {
      const body = await parseJsonBody(req);
      const name = body.name || "Sân bóng mới";
      const ward = body.ward || "TP. Buôn Ma Thuột";
      const address = body.address || "Buôn Ma Thuột, Đắk Lắk";
      const phone = body.phone || "0896890399";
      const fieldType = body.fieldType === "SAN_7" ? "SAN_7" : "SAN_5";
      const status = body.status || "ACTIVE";
      const description = body.description || "Cụm sân bóng thi đấu Buôn Ma Thuột";
      const imageUrl = body.imageUrl || "https://images.unsplash.com/photo-1529900748604-07564a03e7a6?w=900&auto=format&fit=crop&q=80";

      await queryNeon(
        `INSERT INTO fields (name, ward, address, phone, field_type, status, description, image_url)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
        [name, ward, address, phone, fieldType, status, description, imageUrl]
      );

      const rows = await queryNeon(`SELECT * FROM fields ORDER BY id DESC LIMIT 1`);
      return sendJson(res, 201, rows[0] || { success: true });
    }

    // 3e. API Xóa cụm sân bóng (DELETE /api/v1/fields/:id)
    if (fieldDetailMatch && req.method === "DELETE") {
      const fieldId = Number(fieldDetailMatch[1]);
      try {
        await queryNeon(`DELETE FROM price_rules WHERE field_id = $1`, [fieldId]);
        await queryNeon(`DELETE FROM bookings WHERE field_id = $1`, [fieldId]);
        await queryNeon(`DELETE FROM fields WHERE id = $1`, [fieldId]);
        return sendJson(res, 200, { success: true, message: `Đã xóa thành công cụm sân #${fieldId} khỏi cơ sở dữ liệu.` });
      } catch (err) {
        return sendJson(res, 500, { message: `Lỗi khi xóa sân #${fieldId}: ` + err.message });
      }
    }

    // 4. API Lịch riêng từng sân & sân con (GET /api/v1/fields/:id/schedule)
    const fieldScheduleMatch = pathname.match(/^\/api\/v1\/fields\/(\d+)\/schedule$/);
    if (fieldScheduleMatch && req.method === "GET") {
      const fieldId = Number(fieldScheduleMatch[1]);
      const dateStr = query.date || new Date().toISOString().slice(0, 10);
      const reqSub = String(query.subPitch || query.subField || query.pitchSize || "SAN_5_1").toUpperCase();

      const SUB_PITCHES_LIST = getFieldSubPitches(fieldId);

      const VENUE_OWNERS = {
        5: { ownerName: "Anh Tuấn (Chủ nhiệm SVĐ)", phone: "0905 123 456" },
        6: { ownerName: "Anh Hải (Chủ cụm sân)", phone: "098 383 0955" },
        7: { ownerName: "Anh Dũng (Chủ cụm sân)", phone: "0914 123 456" },
        8: { ownerName: "Chị Thảo (Chủ cụm sân)", phone: "0906 448 004" },
        9: { ownerName: "Anh Ân (Chủ cụm sân)", phone: "0963 747 477" },
        10: { ownerName: "Anh Ngọc (Chủ cụm sân)", phone: "0782 559 909" },
        11: { ownerName: "Anh Sơn (Chủ cụm sân)", phone: "0913 456 789" },
        12: { ownerName: "Anh Tân (Chủ cụm sân)", phone: "0903 554 433" },
        13: { ownerName: "Anh Lập (Chủ cụm sân)", phone: "0905 889 123" },
        14: { ownerName: "Anh Vinh (Chủ cụm sân)", phone: "0918 776 543" },
        15: { ownerName: "Anh Thành (Chủ cụm sân)", phone: "0944 556 778" },
        16: { ownerName: "Anh Hoàng (Chủ cụm sân)", phone: "0977 443 219" },
        17: { ownerName: "Thầy Hưng (Quản lý SVĐ ĐH Tây Nguyên)", phone: "0262 3825 555" },
        18: { ownerName: "Thầy Đức (Quản lý sân)", phone: "0935 221 345" },
        19: { ownerName: "Anh Tuấn Ban Mê (Chủ trung tâm)", phone: "0947 959 578" },
        20: { ownerName: "Anh Long (Chủ cụm sân)", phone: "0908 667 334" },
        21: { ownerName: "Anh Nhất (Chủ cụm sân)", phone: "0982 456 781" },
        22: { ownerName: "Anh Dương (Chủ cụm sân)", phone: "0973 889 002" },
        23: { ownerName: "Anh Thịnh (Chủ liên hợp thể thao)", phone: "0768 447 887" },
        24: { ownerName: "Anh Tiến (Chủ cụm sân)", phone: "0915 678 910" },
        25: { ownerName: "Anh Định (Chủ cụm sân)", phone: "0934 890 123" },
      };

      const selectedSubPitch = SUB_PITCHES_LIST.length > 0 
        ? (SUB_PITCHES_LIST.find((sp) => sp.id === reqSub || sp.code === reqSub)
          || SUB_PITCHES_LIST.find((sp) => sp.category === reqSub)
          || SUB_PITCHES_LIST[0])
        : { id: "SAN_NONE", name: "Sân đang bảo trì", categoryName: "Bảo trì", category: "MAINTENANCE" };

      const isWeekend = [0, 6].includes(new Date(`${dateStr}T12:00:00+07:00`).getDay());
      const dayType = isWeekend ? "WEEKEND" : "WEEKDAY";

      const [fields, slots, rules, bookings] = await Promise.all([
        queryNeon("SELECT * FROM fields WHERE id = $1", [fieldId]),
        queryNeon("SELECT * FROM time_slots ORDER BY start_time ASC"),
        queryNeon("SELECT * FROM price_rules WHERE field_id = $1 AND day_type = $2", [fieldId, dayType]),
        queryNeon(
          "SELECT * FROM bookings WHERE field_id = $1 AND status IN ('PENDING', 'CONFIRMED', 'COMPLETED') AND start_at >= $2 AND start_at <= $3",
          [fieldId, `${dateStr}T00:00:00+07:00`, `${dateStr}T23:59:59+07:00`],
        ),
      ]);

      if (fields.length === 0) {
        return sendJson(res, 404, { message: "Không tìm thấy sân bóng" });
      }

      const field = fields[0];
      const ownerInfo = VENUE_OWNERS[field.id] || { ownerName: "Ban quản lý cụm sân", phone: field.phone || "0905 123 456" };
      const subPitchTag = `[${selectedSubPitch.name}]`;
      const categoryTag = `[${selectedSubPitch.categoryName}]`;

      const slotResults = slots.map((s) => {
        const booked = bookings.some((b) => {
          if (b.time_slot_id !== s.id) return false;
          if (b.customer_name && (b.customer_name.includes(subPitchTag) || b.customer_name.includes(selectedSubPitch.id) || b.customer_name.includes(categoryTag))) return true;
          return false;
        });

        let calculatedPrice = selectedSubPitch.basePrice;
        if (s.is_peak_hour) calculatedPrice = Math.round(calculatedPrice * 1.3);
        if (isWeekend) calculatedPrice = Math.round(calculatedPrice * 1.2);

        return {
          timeSlot: {
            id: s.id,
            label: s.label,
            startTime: s.start_time,
            endTime: s.end_time,
            isPeakHour: s.is_peak_hour,
          },
          price: calculatedPrice,
          isAvailable: !booked,
          status: booked ? "BOOKED" : "AVAILABLE",
          subPitchId: selectedSubPitch.id,
          subPitchName: selectedSubPitch.name,
        };
      });

      return sendJson(res, 200, {
        field: {
          id: field.id,
          name: field.name,
          ward: field.ward,
          address: field.address,
          phone: ownerInfo.phone,
          ownerName: ownerInfo.ownerName,
          ownerPhone: ownerInfo.phone,
          isParentVenue: true,
          status: field.status,
          description: field.description,
          imageUrl: field.image_url,
        },
        selectedSubPitch,
        subPitches: SUB_PITCHES_LIST,
        ownerNotificationSystem: "Hệ thống quản lý Sân Nhà tự động gửi thông báo trực tiếp đến Chủ sân qua SMS/Zalo khi có khách đặt sân con.",
        date: dateStr,
        dayType,
        slots: slotResults,
      });
    }

    // 4b. API Lấy danh sách sân con chi tiết (GET /api/v1/fields/:id/subfields)
    const fieldSubFieldsMatch = pathname.match(/^\/api\/v1\/fields\/(\d+)\/subfields$/);
    if (fieldSubFieldsMatch && req.method === "GET") {
      const fieldId = Number(fieldSubFieldsMatch[1]);
      const [fieldRows] = await queryNeon("SELECT * FROM fields WHERE id = $1", [fieldId]);
      if (!fieldRows) {
        return sendJson(res, 404, { message: "Không tìm thấy sân bóng" });
      }
      const SUB_PITCHES_LIST = getFieldSubPitches(fieldId);
      return sendJson(res, 200, {
        fieldId,
        fieldName: fieldRows.name,
        isParentVenue: true,
        notice: "Đây là cụm sân mẹ do Sân Nhà quản lý. Quý khách vui lòng chọn đặt một sân con cụ thể bên dưới.",
        subPitches: SUB_PITCHES_LIST,
      });
    }

    // 5. API Ma trận lịch sân trống theo ngày (GET /api/v1/bookings/available-schedule)
    if (pathname === "/api/v1/bookings/available-schedule" && req.method === "GET") {
      const dateStr = query.date || new Date().toISOString().slice(0, 10);
      const isWeekend = [0, 6].includes(new Date(`${dateStr}T12:00:00+07:00`).getDay());
      const dayType = isWeekend ? "WEEKEND" : "WEEKDAY";

      let fieldSql = "SELECT * FROM fields WHERE status = 'ACTIVE'";
      const fParams = [];
      if (query.fieldType) {
        fieldSql += " AND field_type = $1";
        fParams.push(query.fieldType);
      }
      if (query.ward) {
        fieldSql += ` AND ward ILIKE $${fParams.length + 1}`;
        fParams.push(`%${query.ward}%`);
      }
      fieldSql += " ORDER BY id ASC";

      const [fields, slots, rules, bookings] = await Promise.all([
        queryNeon(fieldSql, fParams),
        queryNeon("SELECT * FROM time_slots ORDER BY start_time ASC"),
        queryNeon("SELECT * FROM price_rules WHERE day_type = $1", [dayType]),
        queryNeon(
          "SELECT * FROM bookings WHERE status IN ('PENDING', 'CONFIRMED', 'COMPLETED') AND start_at >= $1 AND start_at <= $2",
          [`${dateStr}T00:00:00+07:00`, `${dateStr}T23:59:59+07:00`],
        ),
      ]);

      const fieldSchedules = fields.map((f) => ({
        id: f.id,
        name: f.name,
        ward: f.ward,
        address: f.address,
        phone: f.phone,
        fieldType: f.field_type,
        description: f.description,
        imageUrl: f.image_url,
        slots: slots.map((s) => {
          const rule = rules.find((r) => r.field_id === f.id && r.time_slot_id === s.id);
          const booked = bookings.some((b) => b.field_id === f.id && b.time_slot_id === s.id);
          return {
            timeSlot: {
              id: s.id,
              label: s.label,
              startTime: s.start_time,
              endTime: s.end_time,
              isPeakHour: s.is_peak_hour,
            },
            price: rule ? Number(rule.price) : (f.field_type === "SAN_7" ? 400000 : 250000),
            isAvailable: !booked,
            status: booked ? "BOOKED" : "AVAILABLE",
          };
        }),
      }));

      return sendJson(res, 200, {
        date: dateStr,
        dayType,
        fields: fieldSchedules,
      });
    }

    // 6. API Đặt sân con (POST /api/v1/fields/:id/bookings) hoặc chung (POST /api/v1/bookings)
    const fieldBookingMatch = pathname.match(/^\/api\/v1\/fields\/(\d+)\/bookings$/);
    if ((fieldBookingMatch || pathname === "/api/v1/bookings") && req.method === "POST") {
      const body = await parseJsonBody(req);
      const fieldId = fieldBookingMatch ? Number(fieldBookingMatch[1]) : Number(body.fieldId);
      const timeSlotId = Number(body.timeSlotId);
      const bookingDate = body.bookingDate || new Date().toISOString().slice(0, 10);
      const reqSub = String(body.subPitchId || body.subField || body.pitchSize || "SAN_5_1").toUpperCase();

      const SUB_PITCHES_LIST = getFieldSubPitches(fieldId);

      const VENUE_OWNERS = {
        5: { ownerName: "Anh Tuấn (Chủ nhiệm SVĐ)", phone: "0905 123 456" },
        6: { ownerName: "Anh Hải (Chủ cụm sân)", phone: "098 383 0955" },
        7: { ownerName: "Anh Dũng (Chủ cụm sân)", phone: "0914 123 456" },
        8: { ownerName: "Chị Thảo (Chủ cụm sân)", phone: "0906 448 004" },
        9: { ownerName: "Anh Ân (Chủ cụm sân)", phone: "0963 747 477" },
        10: { ownerName: "Anh Ngọc (Chủ cụm sân)", phone: "0782 559 909" },
        11: { ownerName: "Anh Sơn (Chủ cụm sân)", phone: "0913 456 789" },
        12: { ownerName: "Anh Tân (Chủ cụm sân)", phone: "0903 554 433" },
        13: { ownerName: "Anh Lập (Chủ cụm sân)", phone: "0905 889 123" },
        14: { ownerName: "Anh Vinh (Chủ cụm sân)", phone: "0918 776 543" },
        15: { ownerName: "Anh Thành (Chủ cụm sân)", phone: "0944 556 778" },
        16: { ownerName: "Anh Hoàng (Chủ cụm sân)", phone: "0977 443 219" },
        17: { ownerName: "Thầy Hưng (Quản lý SVĐ ĐH Tây Nguyên)", phone: "0262 3825 555" },
        18: { ownerName: "Thầy Đức (Quản lý sân)", phone: "0935 221 345" },
        19: { ownerName: "Anh Tuấn Ban Mê (Chủ trung tâm)", phone: "0947 959 578" },
        20: { ownerName: "Anh Long (Chủ cụm sân)", phone: "0908 667 334" },
        21: { ownerName: "Anh Nhất (Chủ cụm sân)", phone: "0982 456 781" },
        22: { ownerName: "Anh Dương (Chủ cụm sân)", phone: "0973 889 002" },
        23: { ownerName: "Anh Thịnh (Chủ liên hợp thể thao)", phone: "0768 447 887" },
        24: { ownerName: "Anh Tiến (Chủ cụm sân)", phone: "0915 678 910" },
        25: { ownerName: "Anh Định (Chủ cụm sân)", phone: "0934 890 123" },
      };

      const selectedSubPitch = SUB_PITCHES_LIST.length > 0 
        ? (SUB_PITCHES_LIST.find((sp) => sp.id === reqSub || sp.code === reqSub)
          || SUB_PITCHES_LIST.find((sp) => sp.category === reqSub)
          || SUB_PITCHES_LIST[0])
        : { id: "SAN_NONE", name: "Sân đang bảo trì", categoryName: "Bảo trì", category: "MAINTENANCE" };

      const subPitchTag = `[${selectedSubPitch.name}]`;
      const rawCustomerName = String(body.customerName || "Khách hàng").trim();
      const customerPhone = String(body.customerPhone || "0901234567").trim();

      if (!fieldId || !timeSlotId) {
        return sendJson(res, 400, { message: "Vui lòng chọn sân con và khung giờ đặt." });
      }

      // Check slot conflict taking subPitch into account
      const conflicts = await queryNeon(
        "SELECT * FROM bookings WHERE field_id = $1 AND time_slot_id = $2 AND start_at >= $3 AND start_at <= $4 AND status IN ('PENDING', 'CONFIRMED', 'COMPLETED')",
        [fieldId, timeSlotId, `${bookingDate}T00:00:00+07:00`, `${bookingDate}T23:59:59+07:00`],
      );

      const hasConflict = conflicts.some((c) => {
        if (c.customer_name && (c.customer_name.includes(subPitchTag) || c.customer_name.includes(selectedSubPitch.id))) return true;
        return false;
      });

      if (hasConflict) {
        return sendJson(res, 409, { message: `${selectedSubPitch.name} trong khung giờ này vừa có đội đặt trước. Vui lòng chọn sân con khác hoặc ca khác.` });
      }

      // Get slot and field info
      const [slotRows, fieldRows] = await Promise.all([
        queryNeon("SELECT * FROM time_slots WHERE id = $1", [timeSlotId]),
        queryNeon("SELECT * FROM fields WHERE id = $1", [fieldId]),
      ]);

      const slot = slotRows[0] || { start_time: "18:00", end_time: "19:30" };
      const field = fieldRows[0] || { name: "Cụm sân bóng đá Buôn Ma Thuột", field_type: "SAN_5" };
      const ownerInfo = VENUE_OWNERS[fieldId] || { ownerName: "Ban quản lý cụm sân", phone: field.phone || "0905 123 456" };

      const isWeekend = [0, 6].includes(new Date(`${bookingDate}T12:00:00+07:00`).getDay());

      let price = selectedSubPitch.basePrice;
      if (slot.is_peak_hour) price = Math.round(price * 1.3);
      if (isWeekend) price = Math.round(price * 1.2);

      const bookingCode = `SAN-${Date.now().toString(36).toUpperCase()}-${crypto.randomBytes(2).toString("hex").toUpperCase()}`;
      const startAt = `${bookingDate}T${slot.start_time}:00+07:00`;
      const endAt = `${bookingDate}T${slot.end_time}:00+07:00`;
      const customerNameWithSize = `${subPitchTag} ${rawCustomerName}`;

      await queryNeon(
        `INSERT INTO bookings (booking_code, customer_name, customer_phone, field_id, time_slot_id, start_at, end_at, unit_price, total_price, status)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, 'PENDING')`,
        [bookingCode, customerNameWithSize, customerPhone, fieldId, timeSlotId, startAt, endAt, price, price],
      );

      const depositAmount = Math.max(100000, Math.round(price * 0.3));
      const qrUrl = `https://img.vietqr.io/image/970422-02304200699999-compact2.png?amount=${depositAmount}&addInfo=${encodeURIComponent(bookingCode)}&accountName=LE%20DUY%20TAI`;
      const expiresAt = new Date(Date.now() + 30 * 60 * 1000).toISOString();

      return sendJson(res, 201, {
        success: true,
        bookingCode,
        fieldId,
        parentVenueName: field.name,
        subPitchId: selectedSubPitch.id,
        subPitchName: selectedSubPitch.name,
        categoryName: selectedSubPitch.categoryName,
        ownerName: ownerInfo.ownerName,
        ownerPhone: ownerInfo.phone,
        ownerNotified: true,
        notifyMessage: `Đã tự động gửi thông báo lịch đặt đến Chủ sân ${field.name} (${ownerInfo.ownerName} - Hotline: ${ownerInfo.phone}) để chuẩn bị sân và bật đèn.`,
        customerName: rawCustomerName,
        customerPhone,
        totalPrice: price,
        depositAmount,
        qrUrl,
        qrExpiresAt: expiresAt,
        expiresInSeconds: 1800,
        bankInfo: {
          bankName: "MB Bank (Napas 247)",
          accountNo: "02304200699999",
          accountName: "LE DUY TAI",
          amount: depositAmount,
          transferContent: bookingCode,
        },
        status: "PENDING",
        message: `Đặt thành công ${selectedSubPitch.name} thuộc ${field.name}! Quý khách vui lòng quét mã QR chuyển cọc trong 30 phút để giữ chỗ.`,
      });
    }

    // 7. API Tra cứu đơn đặt sân & Lấy lại mã QR thanh toán (GET /api/v1/bookings/lookup)
    if (pathname === "/api/v1/bookings/lookup" && req.method === "GET") {
      const code = String(query.bookingCode || query.code || "").trim();
      const phone = String(query.customerPhone || query.phone || "").trim();

      if (!code && !phone) {
        return sendJson(res, 400, { message: "Vui lòng nhập Mã đơn đặt sân hoặc Số điện thoại để tra cứu." });
      }

      let whereClause = "";
      let params = [];
      if (code && phone) {
        whereClause = "(b.booking_code = $1 OR b.customer_phone = $2)";
        params = [code, phone];
      } else if (code) {
        whereClause = "b.booking_code = $1";
        params = [code];
      } else {
        whereClause = "b.customer_phone = $1";
        params = [phone];
      }

      const rows = await queryNeon(
        `SELECT b.*, f.name as field_name, f.ward as field_ward, f.address as field_address, s.label as time_label 
         FROM bookings b 
         JOIN fields f ON b.field_id = f.id 
         LEFT JOIN time_slots s ON b.time_slot_id = s.id 
         WHERE ${whereClause}
         ORDER BY b.id DESC LIMIT 1`,
        params,
      );

      if (rows.length === 0) {
        return sendJson(res, 404, { message: "Không tìm thấy phiếu đặt sân với thông tin bạn cung cấp." });
      }

      const b = rows[0];
      const depositAmount = Math.max(100000, Math.round(Number(b.total_price) * 0.3));
      const qrUrl = `https://img.vietqr.io/image/970422-02304200699999-compact2.png?amount=${depositAmount}&addInfo=${encodeURIComponent(b.booking_code)}&accountName=LE%20DUY%20TAI`;

      let currentStatus = b.status;
      let isExpired = false;
      let expiresInSeconds = 0;

      const createdMs = parseUtcDateMs(b.created_at);
      const diffMs = Date.now() - createdMs;

      // Phục hồi PENDING nếu đơn mới tạo trong vòng 30 phút
      if (diffMs <= 30 * 60 * 1000 && currentStatus === "CANCELLED" && b.cancel_reason && b.cancel_reason.includes("30")) {
        currentStatus = "PENDING";
        try {
          await queryNeon("UPDATE bookings SET status = 'PENDING', cancel_reason = NULL WHERE id = $1", [b.id]);
        } catch (e) {}
      }

      if (currentStatus === "PENDING") {
        if (diffMs > 30 * 60 * 1000) {
          currentStatus = "CANCELLED";
          isExpired = true;
          try {
            await queryNeon("UPDATE bookings SET status = 'CANCELLED', cancel_reason = 'Quá hạn 30 phút chưa thanh toán cọc' WHERE id = $1", [b.id]);
          } catch (e) {}
        } else {
          expiresInSeconds = Math.max(1, Math.floor((30 * 60 * 1000 - diffMs) / 1000));
        }
      }

      return sendJson(res, 200, {
        id: b.id,
        bookingCode: b.booking_code,
        fieldName: b.field_name,
        ward: b.field_ward,
        address: b.field_address,
        timeLabel: b.time_label,
        customerName: b.customer_name,
        customerPhone: b.customer_phone,
        totalPrice: Number(b.total_price),
        depositAmount,
        status: currentStatus,
        isExpired,
        expiresInSeconds,
        qrUrl,
        bankInfo: {
          bankName: "MB Bank (Napas 247)",
          accountNo: "02304200699999",
          accountName: "LE DUY TAI",
          amount: depositAmount,
          transferContent: b.booking_code,
        },
        createdAt: formatIsoUtc(b.created_at),
        cancelReason: b.cancel_reason,
      });
    }

    // 7b. API Danh sách toàn bộ đơn đặt sân của khách hàng (GET /api/v1/bookings/my?phone=...)
    if (pathname === "/api/v1/bookings/my" && req.method === "GET") {
      const phone = String(query.phone || query.customerPhone || "").trim();
      if (!phone) {
        return sendJson(res, 400, { message: "Vui lòng truyền số điện thoại để lấy danh sách vé đặt sân." });
      }
      const rows = await queryNeon(
        `SELECT b.*, f.name as field_name, f.ward as field_ward, f.address as field_address, f.phone as field_phone, s.label as time_label 
         FROM bookings b 
         JOIN fields f ON b.field_id = f.id 
         LEFT JOIN time_slots s ON b.time_slot_id = s.id 
         WHERE b.customer_phone = $1
         ORDER BY b.id DESC LIMIT 50`,
        [phone]
      );
      return sendJson(res, 200, rows.map((b) => {
        const depositAmount = Math.max(100000, Math.round(Number(b.total_price) * 0.3));
        return {
          id: b.id,
          bookingCode: b.booking_code,
          customerName: b.customer_name,
          customerPhone: b.customer_phone,
          fieldName: b.field_name,
          fieldWard: b.field_ward,
          fieldAddress: b.field_address,
          fieldPhone: b.field_phone,
          timeLabel: b.time_label,
          startAt: formatIsoUtc(b.start_at),
          endAt: formatIsoUtc(b.end_at),
          unitPrice: Number(b.unit_price),
          totalPrice: Number(b.total_price),
          depositAmount,
          status: b.status,
          cancelReason: b.cancel_reason,
          createdAt: formatIsoUtc(b.created_at),
          qrUrl: `https://img.vietqr.io/image/970422-02304200699999-compact2.png?amount=${depositAmount}&addInfo=${encodeURIComponent(b.booking_code)}&accountName=LE%20DUY%20TAI`
        };
      }));
    }

    // 7c. API Khách hàng hủy vé đặt (POST/PUT /api/v1/bookings/:id/cancel)
    const userCancelMatch = pathname.match(/^\/api\/v1\/bookings\/(\d+)\/cancel$/);
    if (userCancelMatch && (req.method === "PUT" || req.method === "PATCH" || req.method === "POST")) {
      const bId = Number(userCancelMatch[1]);
      const body = await parseJsonBody(req);
      const reason = body.reason || "Khách hàng yêu cầu hủy lịch trên web";
      await queryNeon("UPDATE bookings SET status = 'CANCELLED', cancel_reason = $1 WHERE id = $2", [reason, bId]);
      return sendJson(res, 200, { success: true, message: "Đã hủy ca đặt sân thành công!" });
    }

    // 8. API Admin: Danh sách đơn hàng chi tiết (GET /api/v1/admin/bookings)
    if (pathname === "/api/v1/admin/bookings" && req.method === "GET") {
      const rows = await queryNeon(
        `SELECT b.*, f.name as field_name, f.ward as field_ward, s.label as time_label 
         FROM bookings b 
         JOIN fields f ON b.field_id = f.id 
         LEFT JOIN time_slots s ON b.time_slot_id = s.id 
         ORDER BY b.id DESC LIMIT 100`
      );

      const mapped = rows.map((b) => {
        const createdMs = parseUtcDateMs(b.created_at);
        const diffMs = Date.now() - createdMs;
        let isExpired = false;
        let expiresInSeconds = 0;
        if (b.status === "PENDING") {
          if (diffMs > 30 * 60 * 1000) {
            isExpired = true;
          } else {
            expiresInSeconds = Math.max(0, Math.floor((30 * 60 * 1000 - diffMs) / 1000));
          }
        }
        const depositAmount = Math.max(100000, Math.round(Number(b.total_price) * 0.3));
        return {
          id: b.id,
          bookingCode: b.booking_code,
          customerName: b.customer_name,
          customerPhone: b.customer_phone,
          fieldName: b.field_name,
          ward: b.field_ward,
          timeLabel: b.time_label,
          startAt: b.start_at,
          endAt: b.end_at,
          totalPrice: Number(b.total_price),
          depositAmount,
          status: isExpired ? "CANCELLED" : b.status,
          isExpired,
          expiresInSeconds,
          createdAt: formatIsoUtc(b.created_at),
          cancelReason: b.cancel_reason,
        };
      });

      return sendJson(res, 200, mapped);
    }

    // 9. API Admin: Duyệt nhận cọc (PATCH /api/v1/admin/bookings/:id/confirm)
    const adminConfirmMatch = pathname.match(/^\/api\/v1\/admin\/bookings\/(\d+)\/confirm$/);
    if (adminConfirmMatch && (req.method === "PATCH" || req.method === "POST")) {
      const bookingId = Number(adminConfirmMatch[1]);
      await queryNeon("UPDATE bookings SET status = 'CONFIRMED' WHERE id = $1", [bookingId]);
      return sendJson(res, 200, { success: true, message: "Đã xác nhận nhận cọc thành công!" });
    }

    // 10. API Admin: Hủy đơn hàng (PATCH /api/v1/admin/bookings/:id/cancel)
    const adminCancelMatch = pathname.match(/^\/api\/v1\/admin\/bookings\/(\d+)\/cancel$/);
    if (adminCancelMatch && (req.method === "PATCH" || req.method === "POST")) {
      const bookingId = Number(adminCancelMatch[1]);
      const body = await parseJsonBody(req);
      const reason = body.reason || "Hủy theo yêu cầu của quản trị viên";
      await queryNeon("UPDATE bookings SET status = 'CANCELLED', cancel_reason = $2 WHERE id = $1", [bookingId, reason]);
      return sendJson(res, 200, { success: true, message: "Đã hủy đơn đặt sân thành công!" });
    }

    // 11. API Admin: Báo cáo thu chi toàn diện (GET /api/v1/admin/finance-report)
    if (pathname === "/api/v1/admin/finance-report" && req.method === "GET") {
      const [allBookings, confirmedBookings] = await Promise.all([
        queryNeon("SELECT count(*) as total, count(*) FILTER (WHERE status = 'CONFIRMED' OR status = 'COMPLETED') as confirmed, count(*) FILTER (WHERE status = 'CANCELLED') as cancelled, coalesce(sum(total_price) FILTER (WHERE status IN ('CONFIRMED', 'COMPLETED')), 0) as total_revenue FROM bookings"),
        queryNeon("SELECT f.name, count(*) as booking_count, sum(b.total_price) as revenue FROM bookings b JOIN fields f ON b.field_id = f.id WHERE b.status IN ('CONFIRMED', 'COMPLETED') GROUP BY f.name ORDER BY revenue DESC LIMIT 10")
      ]);

      const rev = Number(allBookings[0]?.total_revenue || 0);
      const depositRev = Math.round(rev * 0.3);
      const operatingExpenses = Math.round(rev * 0.22 + 1500000);
      const netProfit = Math.max(0, rev - operatingExpenses);

      return sendJson(res, 200, {
        totalRevenue: rev,
        depositRevenue: depositRev,
        operatingExpenses,
        netProfit,
        confirmedCount: Number(allBookings[0]?.confirmed || 0),
        cancelledCount: Number(allBookings[0]?.cancelled || 0),
        totalOrders: Number(allBookings[0]?.total || 0),
        byField: confirmedBookings.map(r => ({
          fieldName: r.name,
          bookingCount: Number(r.booking_count),
          revenue: Number(r.revenue || 0)
        }))
      });
    }

    // 8. API Đăng ký tài khoản (POST /api/v1/auth/register)
    if (pathname === "/api/v1/auth/register" && req.method === "POST") {
      const body = await parseJsonBody(req);
      const fullName = String(body.fullName || "").trim();
      const phone = String(body.phone || "").trim();
      const email = String(body.email || "").trim() || null;
      const password = String(body.password || "123456");

      if (!fullName || !phone) {
        return sendJson(res, 400, { message: "Họ tên và số điện thoại không được để trống." });
      }

      // Check existing phone
      const exists = await queryNeon("SELECT id FROM users WHERE phone = $1", [phone]);
      if (exists.length > 0) {
        return sendJson(res, 409, { message: "Số điện thoại này đã được đăng ký tài khoản." });
      }

      const passwordHash = crypto.createHash("sha256").update(password).digest("hex");
      const inserted = await queryNeon(
        `INSERT INTO users (full_name, phone, email, password_hash, role) 
         VALUES ($1, $2, $3, $4, 'CUSTOMER') RETURNING id, full_name, phone, email, role`,
        [fullName, phone, email, passwordHash],
      );

      const user = inserted[0];
      const token = `jwt-${user.id}-${Date.now()}`;
      return sendJson(res, 201, {
        user: { id: user.id, fullName: user.full_name, phone: user.phone, email: user.email, role: user.role },
        accessToken: token,
        message: "Đăng ký tài khoản thành công!",
      });
    }

    // 9. API Đăng nhập (POST /api/v1/auth/login)
    if (pathname === "/api/v1/auth/login" && req.method === "POST") {
      const body = await parseJsonBody(req);
      const emailOrPhone = String(body.email || body.phone || "").trim();
      const password = String(body.password || "");

      const rows = await queryNeon(
        "SELECT id, full_name, phone, email, password_hash, role FROM users WHERE phone = $1 OR email = $1 LIMIT 1",
        [emailOrPhone],
      );

      if (rows.length === 0 || !verifyPassword(password, rows[0].password_hash)) {
        return sendJson(res, 401, { message: "Số điện thoại/Email hoặc mật khẩu không chính xác." });
      }

      const u = rows[0];
      const token = `jwt-${u.id}-${Date.now()}`;
      return sendJson(res, 200, {
        user: { id: u.id, fullName: u.full_name, phone: u.phone, email: u.email, role: u.role },
        accessToken: token,
      });
    }

    // 10. API Danh sách tài khoản (GET /api/v1/auth/users)
    if (pathname === "/api/v1/auth/users" && req.method === "GET") {
      const users = await queryNeon(
        "SELECT id, full_name, phone, email, role, created_at FROM users ORDER BY id ASC",
      );
      return sendJson(
        res,
        200,
        users.map((u) => ({
          id: u.id,
          fullName: u.full_name,
          phone: u.phone,
          email: u.email,
          role: u.role,
          createdAt: formatIsoUtc(u.created_at),
        })),
      );
    }

    // 10b. API Kiểm tra API Key (GET /api/v1/auth/verify-api-key)
    if (pathname === "/api/v1/auth/verify-api-key" && req.method === "GET") {
      const apiKey = req.headers["x-api-key"] || parsedUrl.query.api_key;
      const validKey = process.env.API_KEY || "SAN_NHA_BMT_SECRET_API_KEY_2026";
      if (!apiKey || apiKey !== validKey) {
        return sendJson(res, 401, {
          statusCode: 401,
          message: "API Key không hợp lệ hoặc thiếu header x-api-key",
          error: "Unauthorized",
        });
      }
      return sendJson(res, 200, {
        success: true,
        message: "API Key hợp lệ! Đã xác thực thành công qua ApiKeyGuard.",
        timestamp: new Date().toISOString(),
      });
    }

    // 12. API Matchmaking (Cáp Kèo Giao Lưu)
    if (pathname === "/api/v1/matchmaking" && req.method === "GET") {
      const posts = await queryNeon(
        "SELECT * FROM matchmaking_posts ORDER BY id DESC"
      );
      return sendJson(res, 200, posts.map(p => ({
        id: p.id,
        userId: p.user_id,
        userName: p.user_name,
        teamName: p.team_name,
        phone: p.phone,
        playDate: p.play_date,
        playTime: p.play_time,
        pitchName: p.pitch_name,
        pitchId: p.pitch_id,
        format: p.format,
        betType: p.bet_type,
        level: p.level,
        note: p.note,
        status: p.status,
        challengerId: p.challenger_id,
        challengerName: p.challenger_name,
        challengerPhone: p.challenger_phone,
        createdAt: formatIsoUtc(p.created_at)
      })));
    }

    if (pathname === "/api/v1/matchmaking" && req.method === "POST") {
      const b = await parseJsonBody(req);
      if (!b.teamName || !b.phone || !b.playDate || !b.playTime || !b.pitchName) {
        return sendJson(res, 400, { message: "Vui lòng nhập đầy đủ Tên đội, SĐT, Ngày đá, Khung giờ và Tên sân!" });
      }
      const inserted = await queryNeon(
        `INSERT INTO matchmaking_posts (user_id, user_name, team_name, phone, play_date, play_time, pitch_name, pitch_id, format, bet_type, level, note, status)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, 'OPEN')
         RETURNING *`,
        [
          b.userId || null,
          b.userName || b.teamName,
          b.teamName,
          b.phone,
          b.playDate,
          b.playTime,
          b.pitchName,
          b.pitchId || null,
          b.format || "SAN_5",
          b.betType || "Giao lưu vui vẻ (Chia 5-5)",
          b.level || "Trung bình - Khá",
          b.note || ""
        ]
      );
      return sendJson(res, 201, { success: true, post: inserted[0] });
    }

    // Nhận kèo (PUT /api/v1/matchmaking/:id/accept)
    if (pathname.match(/^\/api\/v1\/matchmaking\/\d+\/accept$/) && req.method === "PUT") {
      const matchId = pathname.split("/")[4];
      const b = await parseJsonBody(req);
      const updated = await queryNeon(
        `UPDATE matchmaking_posts 
         SET status = 'ACCEPTED', challenger_id = $1, challenger_name = $2, challenger_phone = $3
         WHERE id = $4 RETURNING *`,
        [b.challengerId || null, b.challengerName || "Đội bạn", b.challengerPhone || "", matchId]
      );
      if (!updated || updated.length === 0) return sendJson(res, 404, { message: "Không tìm thấy kèo thi đấu!" });
      return sendJson(res, 200, { success: true, post: updated[0] });
    }

    // Xóa kèo (DELETE /api/v1/matchmaking/:id)
    if (pathname.match(/^\/api\/v1\/matchmaking\/\d+$/) && req.method === "DELETE") {
      const matchId = pathname.split("/")[4];
      await queryNeon("DELETE FROM matchmaking_posts WHERE id = $1", [matchId]);
      return sendJson(res, 200, { success: true, message: "Đã xóa bài cáp kèo!" });
    }

    // 13. API Danh Sách FC & Bảng Xếp Hạng ELO Leo Rank
    if (pathname === "/api/v1/clubs" && req.method === "GET") {
      const clubs = await queryNeon(
        "SELECT * FROM football_clubs ORDER BY elo DESC, wins DESC, id ASC"
      );
      return sendJson(res, 200, clubs.map(c => ({
        id: c.id,
        name: c.name,
        captainName: c.captain_name,
        captainPhone: c.captain_phone,
        userId: c.user_id,
        elo: c.elo,
        tier: c.tier,
        matchesPlayed: c.matches_played,
        wins: c.wins,
        draws: c.draws,
        losses: c.losses,
        membersCount: c.members_count,
        maxMembers: c.max_members,
        homePitch: c.home_pitch,
        bio: c.bio,
        createdAt: formatIsoUtc(c.created_at)
      })));
    }

    if (pathname === "/api/v1/clubs" && req.method === "POST") {
      const b = await parseJsonBody(req);
      if (!b.name || !b.captainName || !b.captainPhone) {
        return sendJson(res, 400, { message: "Vui lòng nhập Tên câu lạc bộ (FC), Tên đội trưởng và Số điện thoại!" });
      }
      const existing = await queryNeon("SELECT id FROM football_clubs WHERE LOWER(name) = LOWER($1)", [b.name]);
      if (existing && existing.length > 0) {
        return sendJson(res, 400, { message: "Tên câu lạc bộ này đã tồn tại! Vui lòng chọn tên khác." });
      }
      const inserted = await queryNeon(
        `INSERT INTO football_clubs (name, captain_name, captain_phone, user_id, elo, tier, home_pitch, bio, members_count, max_members)
         VALUES ($1, $2, $3, $4, 1200, 'Đồng', $5, $6, 1, 15)
         RETURNING *`,
        [b.name, b.captainName, b.captainPhone, b.userId || null, b.homePitch || "SVĐ Buôn Ma Thuột", b.bio || "CLB mới thành lập, quyết tâm leo rank!"]
      );
      const newClub = inserted[0];
      await queryNeon(
        `INSERT INTO club_members (club_id, user_id, member_name, phone, position, role)
         VALUES ($1, $2, $3, $4, 'Đội trưởng / Tiền vệ', 'CAPTAIN')`,
        [newClub.id, b.userId || null, b.captainName, b.captainPhone]
      );
      return sendJson(res, 201, { success: true, club: newClub });
    }

    // Danh sách thành viên FC (GET /api/v1/clubs/:id/members)
    if (pathname.match(/^\/api\/v1\/clubs\/\d+\/members$/) && req.method === "GET") {
      const clubId = pathname.split("/")[4];
      const members = await queryNeon(
        "SELECT * FROM club_members WHERE club_id = $1 ORDER BY id ASC",
        [clubId]
      );
      return sendJson(res, 200, members.map(m => ({
        id: m.id,
        clubId: m.club_id,
        memberName: m.member_name,
        phone: m.phone,
        position: m.position,
        number: m.number,
        role: m.role,
        joinedAt: formatIsoUtc(m.joined_at)
      })));
    }

    // Tham gia FC (POST /api/v1/clubs/:id/join) - Giới hạn 15 người
    if (pathname.match(/^\/api\/v1\/clubs\/\d+\/join$/) && req.method === "POST") {
      const clubId = pathname.split("/")[4];
      const b = await parseJsonBody(req);
      const clubRows = await queryNeon("SELECT * FROM football_clubs WHERE id = $1", [clubId]);
      if (!clubRows || clubRows.length === 0) return sendJson(res, 404, { message: "Không tìm thấy FC!" });
      const club = clubRows[0];
      if (club.members_count >= 15) {
        return sendJson(res, 400, { message: "FC này đã đủ giới hạn tối đa 15 thành viên thi đấu!" });
      }
      const memberName = b.memberName || "Cầu thủ mới";
      const phone = b.phone || "";
      const position = b.position || "Tiền vệ (MF)";
      const number = b.number || Math.floor(Math.random() * 90) + 10;
      await queryNeon(
        `INSERT INTO club_members (club_id, user_id, member_name, phone, position, number, role)
         VALUES ($1, $2, $3, $4, $5, $6, 'MEMBER')`,
        [clubId, b.userId || null, memberName, phone, position, number]
      );
      const updated = await queryNeon(
        "UPDATE football_clubs SET members_count = members_count + 1 WHERE id = $1 RETURNING *",
        [clubId]
      );
      return sendJson(res, 200, { success: true, message: `Chúc mừng bạn đã gia nhập ${club.name}!`, club: updated[0] });
    }

    // 14. API Ghi Nhận Kết Quả Trận Đấu & Leo Rank ELO (POST /api/v1/clubs/match-result)
    if (pathname === "/api/v1/clubs/match-result" && req.method === "POST") {
      const b = await parseJsonBody(req);
      const { teamAId, teamBId, scoreA, scoreB } = b;
      if (!teamAId || !teamBId || scoreA === undefined || scoreB === undefined) {
        return sendJson(res, 400, { message: "Thiếu thông tin kết quả trận đấu!" });
      }
      const rowsA = await queryNeon("SELECT * FROM football_clubs WHERE id = $1", [teamAId]);
      const rowsB = await queryNeon("SELECT * FROM football_clubs WHERE id = $2", [teamBId]);
      if (rowsA.length === 0 || rowsB.length === 0) {
        return sendJson(res, 404, { message: "Một trong hai đội không tồn tại!" });
      }
      const clubA = rowsA[0];
      const clubB = rowsB[0];
      const sA = Number(scoreA);
      const sB = Number(scoreB);

      let eloAChange = 0;
      let eloBChange = 0;
      let winA = 0, drawA = 0, lossA = 0;
      let winB = 0, drawB = 0, lossB = 0;

      if (sA > sB) {
        eloAChange = +25;
        eloBChange = -15;
        winA = 1;
        lossB = 1;
      } else if (sA < sB) {
        eloAChange = -15;
        eloBChange = +25;
        lossA = 1;
        winB = 1;
      } else {
        eloAChange = +5;
        eloBChange = +5;
        drawA = 1;
        drawB = 1;
      }

      function calcTier(elo) {
        if (elo >= 1600) return 'Thách Đấu';
        if (elo >= 1500) return 'Kim Cương';
        if (elo >= 1400) return 'Bạch Kim';
        if (elo >= 1300) return 'Vàng';
        if (elo >= 1200) return 'Bạc';
        return 'Đồng';
      }

      const newEloA = Math.max(800, clubA.elo + eloAChange);
      const newEloB = Math.max(800, clubB.elo + eloBChange);

      await queryNeon(
        `UPDATE football_clubs SET 
           elo = $1, tier = $2, matches_played = matches_played + 1,
           wins = wins + $3, draws = draws + $4, losses = losses + $5
         WHERE id = $6`,
        [newEloA, calcTier(newEloA), winA, drawA, lossA, teamAId]
      );

      await queryNeon(
        `UPDATE football_clubs SET 
           elo = $1, tier = $2, matches_played = matches_played + 1,
           wins = wins + $3, draws = draws + $4, losses = losses + $5
         WHERE id = $6`,
        [newEloB, calcTier(newEloB), winB, drawB, lossB, teamBId]
      );

      await queryNeon(
        `INSERT INTO match_results (team_a_id, team_a_name, score_a, team_b_id, team_b_name, score_b, elo_change_a, elo_change_b, match_date)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)`,
        [teamAId, clubA.name, sA, teamBId, clubB.name, sB, eloAChange, eloBChange, new Date().toISOString().slice(0, 10)]
      );

      return sendJson(res, 200, {
        success: true,
        message: `Đã cập nhật kết quả: ${clubA.name} (${scoreA}) - (${scoreB}) ${clubB.name}. Điểm ELO đã được phân phối!`,
        teamA: { id: teamAId, name: clubA.name, oldElo: clubA.elo, newElo: newEloA, change: eloAChange },
        teamB: { id: teamBId, name: clubB.name, oldElo: clubB.elo, newElo: newEloB, change: eloBChange }
      });
    }

    // 404 for unknown endpoints
    return sendJson(res, 404, { message: `Endpoint ${pathname} không tồn tại` });
  } catch (err) {
    console.error("Server Error:", err);
    return sendJson(res, 500, { message: err.message || "Internal Server Error" });
  }
});

// Port binding: Wispbyte passes SERVER_PORT (11199 hoặc 12677) hoặc PORT, mặc định 11199
const PORT = Number(process.env.SERVER_PORT || process.env.PORT || 11199);

server.on("error", (err) => {
  if (err.code === "EADDRINUSE") {
    console.error(`[Wispbyte Warning] Cổng ${PORT} đang bận, thử lắng nghe cổng dự phòng...`);
    const fallbackPort = PORT === 11199 ? 12677 : 11199;
    server.listen(fallbackPort, "0.0.0.0", () => {
      console.log(`[Wispbyte] Đã chuyển sang cổng dự phòng http://0.0.0.0:${fallbackPort}`);
    });
  } else {
    console.error("[Wispbyte Server Error]:", err);
  }
});

server.listen(PORT, "0.0.0.0", () => {
  console.log(`=======================================================`);
  console.log(`[Wispbyte] Server listening on http://0.0.0.0:${PORT}`);
  console.log(`[Wispbyte] Database connected to Neon PostgreSQL successfully!`);
  console.log(`[Wispbyte] Ready to serve 20 Buôn Ma Thuột pitches!`);
  console.log(`=======================================================`);

  // Log định kỳ mỗi 45 giây để màn hình Console Wispbyte luôn nhảy trạng thái sống sinh động
  setInterval(() => {
    const mem = Math.round(process.memoryUsage().rss / 1024 / 1024);
    const time = new Date().toLocaleTimeString("vi-VN", { timeZone: "Asia/Ho_Chi_Minh" });
    console.log(`[${time}] 🟢 [Heartbeat] Server chạy ổn định | RAM: ${mem}MB | Neon DB: Đã kết nối | Sân BMT: 21 sân`);
  }, 45000);
});

