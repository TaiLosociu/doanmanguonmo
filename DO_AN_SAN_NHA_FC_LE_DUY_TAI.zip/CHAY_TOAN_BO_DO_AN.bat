@echo off
title Khoi dong Do An San Nha FC (Port 3001)
color 0B
echo ========================================================
echo    DANG KHOI CHAY HE THONG SAN NHA FC (PORT 3001)
echo ========================================================
echo.
cd /d "%~dp0\SAN_NHA_FC_WEB"

if not exist "node_modules" (
    echo [1/2] Dang cai dat thu vien npm...
    call npm install
)

echo [2/2] Dang khoi chay Next.js tai cong 3001...
start "" "http://localhost:3001"
call npm run dev
pause
